<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "b05f65eeb83c23f12bd5d8fe1751ef2d": {
        "title": "Bob",
        "excerpt": "Bob bobber &amp;",
        "status": "pending",
        "page_uuid": "3a0ee0b048545bd22a60e35b5400c54b",
        "parent_uid": "",
        "author": "guest::66a7a87c4ec02e70b4fbfc81e5655769",
        "date": "2025-03-09 10:48:59"
    },
    "cd0f892b42a8c7ab7fa3a4e38fe13c25": {
        "title": "Testing the Comments function",
        "excerpt": "This would be really cool if it works!",
        "status": "pending",
        "page_uuid": "3a0ee0b048545bd22a60e35b5400c54b",
        "parent_uid": "",
        "author": "guest::9e395fbe1178019125816c840df820b2",
        "date": "2025-03-09 10:20:39"
    },
    "5a6e27b5c770293ae1a3113ef8253013": {
        "title": "Nice car",
        "excerpt": "Really does look like new. Needs a roof rack, tho.",
        "status": "pending",
        "page_uuid": "79d647da94f6113506bccaf4dd9cd16d",
        "parent_uid": "",
        "author": "guest::9ddf02f29c60bd8f201ae9a524adbe25",
        "date": "2025-02-27 21:48:08"
    },
    "d99d819c6ca4bf20dd7691f71c51540a": {
        "title": "Testing the comments",
        "excerpt": "Hope this works!",
        "status": "pending",
        "page_uuid": "f93010900b90ddf4ef9b270e772d093c",
        "parent_uid": "",
        "author": "guest::7bce76a7223258a261cb0ebea5dd73a6",
        "date": "2025-02-24 11:13:08"
    },
    "eacd58e42417b1f84c8c5860c2e46c1e": {
        "title": "Sweetie ",
        "excerpt": "She doesn\u2019t look so tough now!",
        "status": "pending",
        "page_uuid": "7842b4a724036928ab95b8c7fde6b594",
        "parent_uid": "",
        "author": "guest::d84fb9a436bc72bc0db0c867ac31b210",
        "date": "2025-02-23 23:03:28"
    }
}
<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "d84fb9a436bc72bc0db0c867ac31b210": {
        "username": "Octavio Masomenos",
        "email": "octmaso@menos.co",
        "hash": "4001c7791a1ba001288be6f8ef5a7159",
        "blocked": false,
        "comments": [
            "eacd58e42417b1f84c8c5860c2e46c1e"
        ]
    },
    "7bce76a7223258a261cb0ebea5dd73a6": {
        "username": "Dude",
        "email": "commenttester@donnybahama.com",
        "hash": "29ebc87f7354e53db75bd94b4dea97b9",
        "blocked": false,
        "comments": [
            "d99d819c6ca4bf20dd7691f71c51540a"
        ]
    },
    "9ddf02f29c60bd8f201ae9a524adbe25": {
        "username": "Seymour Butts",
        "email": "c.moore@butts.co",
        "hash": "0c1dfa17114d732f972ad314c498add1",
        "blocked": false,
        "comments": [
            "5a6e27b5c770293ae1a3113ef8253013"
        ]
    },
    "9e395fbe1178019125816c840df820b2": {
        "username": "OctavioMasomenos",
        "email": "octavio@gmx.com",
        "hash": "402891021d0ece623aa5582ed0130905",
        "blocked": false,
        "comments": [
            "cd0f892b42a8c7ab7fa3a4e38fe13c25"
        ]
    },
    "66a7a87c4ec02e70b4fbfc81e5655769": {
        "username": "Bob",
        "email": "bob@bob.bob",
        "hash": "402891021d0ece623aa5582ed0130905",
        "blocked": false,
        "comments": [
            "b05f65eeb83c23f12bd5d8fe1751ef2d"
        ]
    }
}
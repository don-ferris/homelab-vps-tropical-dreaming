<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "d99d819c6ca4bf20dd7691f71c51540a": {
        "type": "comment",
        "depth": 1,
        "title": "Testing the comments",
        "status": "pending",
        "comment": "Hope this works!",
        "rating": [
            0,
            0
        ],
        "page_uuid": "f93010900b90ddf4ef9b270e772d093c",
        "parent_uid": "",
        "author": "guest::7bce76a7223258a261cb0ebea5dd73a6",
        "subscribe": false,
        "date": "2025-02-24 11:13:08",
        "dateModified": "",
        "dateAudit": "",
        "custom": []
    }
}
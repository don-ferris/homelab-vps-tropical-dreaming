<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "5a6e27b5c770293ae1a3113ef8253013": {
        "type": "comment",
        "depth": 1,
        "title": "Nice car",
        "status": "pending",
        "comment": "Really does look like new. Needs a roof rack, tho.",
        "rating": [
            0,
            0
        ],
        "page_uuid": "79d647da94f6113506bccaf4dd9cd16d",
        "parent_uid": "",
        "author": "guest::9ddf02f29c60bd8f201ae9a524adbe25",
        "subscribe": false,
        "date": "2025-02-27 21:48:08",
        "dateModified": "",
        "dateAudit": "",
        "custom": []
    }
}
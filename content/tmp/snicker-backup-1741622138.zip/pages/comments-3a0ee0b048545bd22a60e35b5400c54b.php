<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "b05f65eeb83c23f12bd5d8fe1751ef2d": {
        "type": "comment",
        "depth": 1,
        "title": "Bob",
        "status": "pending",
        "comment": "Bob bobber &amp;",
        "rating": [
            0,
            0
        ],
        "page_uuid": "3a0ee0b048545bd22a60e35b5400c54b",
        "parent_uid": "",
        "author": "guest::66a7a87c4ec02e70b4fbfc81e5655769",
        "subscribe": false,
        "date": "2025-03-09 10:48:59",
        "dateModified": "",
        "dateAudit": "",
        "custom": []
    },
    "cd0f892b42a8c7ab7fa3a4e38fe13c25": {
        "type": "comment",
        "depth": 1,
        "title": "Testing the Comments function",
        "status": "pending",
        "comment": "This would be really cool if it works!",
        "rating": [
            0,
            0
        ],
        "page_uuid": "3a0ee0b048545bd22a60e35b5400c54b",
        "parent_uid": "",
        "author": "guest::9e395fbe1178019125816c840df820b2",
        "subscribe": false,
        "date": "2025-03-09 10:20:39",
        "dateModified": "",
        "dateAudit": "",
        "custom": []
    }
}
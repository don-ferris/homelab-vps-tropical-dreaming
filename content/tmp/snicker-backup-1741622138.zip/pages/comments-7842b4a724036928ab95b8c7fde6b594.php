<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "eacd58e42417b1f84c8c5860c2e46c1e": {
        "type": "comment",
        "depth": 1,
        "title": "Sweetie ",
        "status": "pending",
        "comment": "She doesn\u2019t look so tough now!",
        "rating": [
            0,
            0
        ],
        "page_uuid": "7842b4a724036928ab95b8c7fde6b594",
        "parent_uid": "",
        "author": "guest::d84fb9a436bc72bc0db0c867ac31b210",
        "subscribe": false,
        "date": "2025-02-23 23:03:28",
        "dateModified": "",
        "dateAudit": "",
        "custom": []
    }
}